Clementine Defender Web

This version is touch-friendly and intended for iPhone Safari.

Run locally:
python -m http.server 8000

Then open:
http://localhost:8000/clementine_web/

Controls:
- Aim slider
- Power slider
- Start / Throw button

For iPhone:
- serve the folder from a local or remote web server
- open it in Safari
- optionally add it to the Home Screen
