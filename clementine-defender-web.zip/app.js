const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
const statusText = document.getElementById("statusText");
const aimSlider = document.getElementById("aimSlider");
const powerSlider = document.getElementById("powerSlider");
const throwBtn = document.getElementById("throwBtn");

const WIDTH = 1000;
const HEIGHT = 650;
const PLAYER_X = 180;
const GROUND_Y = 560;
const ROCKET_X = 845;
const ROCKET_Y = 380;
const GRAVITY = 0.42;
const THROW_SPEED = 12.5;

const stages = [
  { name: "Level 1", kind: "normal", hp: 3 },
  { name: "Level 2", kind: "fast", hp: 5 },
  { name: "Level 3", kind: "tanky", hp: 7 },
  { name: "Level 4", kind: "sahar", hp: 2 },
];

const assetPaths = {
  cover: "./assets/cover.png",
  sahar: "./assets/boss/sahar.png",
  rockets: {
    normal: "./assets/rocket/normal.png",
    fast: "./assets/rocket/fast.png",
    tanky: "./assets/rocket/tanky.png",
  },
  player: Array.from({ length: 25 }, (_, i) => `./assets/player/frame_${String(i).padStart(2, "0")}.png`),
};

const assets = {
  rockets: {},
  player: [],
};

const state = {
  mode: "title",
  aim: -35,
  power: 1,
  ammo: 18,
  stageIndex: 0,
  stageHits: 0,
  totalHits: 0,
  rocketDx: 0,
  rocketDy: 0,
  rocketDir: 1,
  rocketTimer: 0,
  playerAnim: 0,
  screenShake: 0,
  endAnim: 0,
  dialogueTimer: 0,
  projectiles: [],
  explosions: [],
  message: "Tap Start to begin.",
};

function loadImage(src) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

async function loadAssets() {
  assets.cover = await loadImage(assetPaths.cover);
  assets.sahar = await loadImage(assetPaths.sahar);
  assets.rockets.normal = await loadImage(assetPaths.rockets.normal);
  assets.rockets.fast = await loadImage(assetPaths.rockets.fast);
  assets.rockets.tanky = await loadImage(assetPaths.rockets.tanky);
  assets.player = await Promise.all(assetPaths.player.map(loadImage));
}

function currentStage() {
  return stages[state.stageIndex];
}

function resetGame() {
  state.mode = "title";
  state.ammo = 18;
  state.stageIndex = 0;
  state.stageHits = 0;
  state.totalHits = 0;
  state.rocketDx = 0;
  state.rocketDy = 0;
  state.rocketDir = 1;
  state.rocketTimer = 0;
  state.playerAnim = 0;
  state.screenShake = 0;
  state.endAnim = 0;
  state.dialogueTimer = 0;
  state.projectiles = [];
  state.explosions = [];
  state.message = "Tap Start to begin.";
}

function stageStartMessage() {
  const stage = currentStage();
  return `${stage.name}: ${stage.kind.toUpperCase()} incoming.`;
}

function getThrowOrigin() {
  const radians = state.aim * Math.PI / 180;
  return {
    x: PLAYER_X + 44 + Math.cos(radians) * 38,
    y: GROUND_Y - 170 + Math.sin(radians) * 38,
  };
}

function spawnExplosion(x, y, burst = 3) {
  for (let i = 0; i < burst; i += 1) {
    state.explosions.push({
      x: x + Math.random() * 36 - 18,
      y: y + Math.random() * 36 - 18,
      life: 10 + Math.floor(Math.random() * 8),
    });
  }
}

function getSaharPosition() {
  return {
    x: ROCKET_X + state.rocketDx * 8,
    y: ROCKET_Y - 10 + state.rocketDy * 12,
  };
}

function getSaharShields() {
  const p = getSaharPosition();
  if (state.stageHits === 0) return [{ x: p.x - 120, y: p.y + 10 }, { x: p.x + 120, y: p.y + 10 }];
  if (state.stageHits === 1) return [{ x: p.x + 120, y: p.y + 10 }];
  return [];
}

function throwClementine() {
  if (state.dialogueTimer > 0) return;
  if (state.mode === "title") {
    state.mode = "playing";
    state.message = stageStartMessage();
    state.playerAnim = 18;
    return;
  }
  if (state.mode !== "playing" || state.ammo <= 0) return;

  const radians = state.aim * Math.PI / 180;
  const origin = getThrowOrigin();
  const speed = THROW_SPEED * state.power;
  state.projectiles.push({
    x: origin.x,
    y: origin.y,
    vx: Math.cos(radians) * speed,
    vy: Math.sin(radians) * speed,
  });
  state.ammo -= 1;
  state.playerAnim = 18;
  state.message = `Throwing at ${Math.round(state.power * 100)}% power.`;
}

function advanceStage() {
  spawnExplosion(ROCKET_X, ROCKET_Y, 10);
  if (state.stageIndex >= stages.length - 1) {
    state.mode = "won";
    state.endAnim = 120;
    state.message = "SAHAR is beaten.";
    return;
  }

  state.stageIndex += 1;
  state.stageHits = 0;
  state.projectiles = [];
  state.ammo = 18;
  state.rocketDx = 0;
  state.rocketDy = 0;
  state.rocketDir = 1;
  state.rocketTimer = 0;
  state.screenShake = 10;
  state.message = `${currentStage().name} begins.`;
  if (currentStage().kind === "sahar") {
    state.dialogueTimer = 240;
  }
}

function update() {
  if (state.mode === "playing") {
    if (state.dialogueTimer > 0) {
      state.dialogueTimer -= 1;
    } else {
      state.rocketTimer += 1;
      if (state.rocketTimer % 90 === 0) state.rocketDir *= -1;
      state.rocketDx += 0.08 * state.rocketDir;
      state.rocketDx = Math.max(-2.4, Math.min(2.4, state.rocketDx));
      state.rocketDy = Math.sin(state.rocketTimer / 18) * 1.1;

      const next = [];
      const stage = currentStage();
      const boss = stage.kind === "sahar";
      const bossPos = getSaharPosition();
      const shields = getSaharShields();
      for (const fruit of state.projectiles) {
        fruit.x += fruit.vx;
        fruit.y += fruit.vy;
        fruit.vy += GRAVITY;

        let hit = false;
        if (boss) {
          if (fruit.x >= bossPos.x - 55 && fruit.x <= bossPos.x + 55 && fruit.y >= bossPos.y - 70 && fruit.y <= bossPos.y + 70) hit = true;
          for (const shield of shields) {
            if (fruit.x >= shield.x - 38 && fruit.x <= shield.x + 38 && fruit.y >= shield.y - 70 && fruit.y <= shield.y + 70) hit = true;
          }
        } else {
          const rx = ROCKET_X + state.rocketDx * 8;
          const ry = ROCKET_Y + state.rocketDy * 12;
          hit = fruit.x >= rx - 42 && fruit.x <= rx + 42 && fruit.y >= ry - 88 && fruit.y <= ry + 72;
        }

        if (hit) {
          state.stageHits += 1;
          state.totalHits += 1;
          state.message = `${stage.kind.toUpperCase()} hit ${state.stageHits}/${stage.hp}`;
          state.screenShake = 8;
          spawnExplosion(fruit.x, fruit.y, 4);
          if (state.stageHits >= stage.hp) advanceStage();
          continue;
        }

        if (fruit.x > -50 && fruit.x < WIDTH + 50 && fruit.y < HEIGHT + 50) next.push(fruit);
      }
      state.projectiles = next;

      if (state.ammo === 0 && state.projectiles.length === 0 && state.stageHits < stage.hp) {
        state.mode = "lost";
        state.endAnim = 90;
        state.message = "The enemy survived. Tap restart.";
      }
    }
  }

  state.explosions = state.explosions
    .map((e) => ({ ...e, life: e.life - 1 }))
    .filter((e) => e.life > 0);
  if (state.playerAnim > 0) state.playerAnim -= 1;
  if (state.screenShake > 0) state.screenShake -= 1;
  if (state.endAnim > 0) state.endAnim -= 1;
}

function drawImageCentered(img, x, y, scale = 1) {
  if (!img) return;
  const w = img.width * scale;
  const h = img.height * scale;
  ctx.drawImage(img, x - w / 2, y - h / 2, w, h);
}

function drawBackground() {
  if (assets.cover) {
    ctx.drawImage(assets.cover, 0, 0, WIDTH, HEIGHT);
    return;
  }
  ctx.fillStyle = "#9ed9ff";
  ctx.fillRect(0, 0, WIDTH, HEIGHT);
}

function currentPlayerFrame() {
  if (state.playerAnim <= 0) return assets.player[0];
  const idx = Math.min(24, Math.max(0, Math.floor(((18 - state.playerAnim) / 18) * 25)));
  return assets.player[idx] || assets.player[0];
}

function drawPlayer() {
  const frame = currentPlayerFrame();
  let y = GROUND_Y - 160;
  if (state.mode === "won" && state.stageIndex === stages.length - 1) y -= Math.abs(Math.sin((120 - state.endAnim) / 7)) * 55;
  drawImageCentered(frame, PLAYER_X, y, 1);

  const origin = getThrowOrigin();
  ctx.strokeStyle = "rgba(255,255,255,0.85)";
  ctx.setLineDash([8, 8]);
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(origin.x, origin.y);
  ctx.lineTo(origin.x + Math.cos(state.aim * Math.PI / 180) * 58, origin.y + Math.sin(state.aim * Math.PI / 180) * 58);
  ctx.stroke();
  ctx.setLineDash([]);

  if (state.mode === "won" && state.stageIndex === stages.length - 1) {
    ctx.strokeStyle = "#222";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(PLAYER_X + 5, y - 18, 12, 0.2, 2.8);
    ctx.stroke();
    ctx.strokeStyle = "#8b5a2b";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(PLAYER_X + 18, y - 20);
    ctx.lineTo(PLAYER_X + 34, y - 18);
    ctx.stroke();
    ctx.strokeStyle = "#d8d8d8";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(PLAYER_X + 36, y - 18);
    ctx.lineTo(PLAYER_X + 52, y - 28);
    ctx.stroke();
  }
}

function drawRocketStage() {
  const stage = currentStage();
  if (stage.kind === "sahar") {
    const pos = getSaharPosition();
    if (assets.sahar) {
      drawImageCentered(assets.sahar, pos.x, pos.y, 0.9);
    } else {
      ctx.fillStyle = "#23428f";
      ctx.fillRect(pos.x - 24, pos.y - 40, 48, 80);
    }
    for (const [i, shield] of getSaharShields().entries()) {
      const img = [assets.rockets.normal, assets.rockets.fast][i] || assets.rockets.normal;
      drawImageCentered(img, shield.x, shield.y, 0.45);
    }
    return;
  }

  const x = ROCKET_X + state.rocketDx * 8;
  let y = ROCKET_Y + state.rocketDy * 12;
  if (state.mode === "won" && state.endAnim > 0) y -= (120 - state.endAnim) * 1.4;
  if (state.mode === "lost" && state.endAnim > 0) y += Math.sin(state.endAnim / 4) * 10;
  drawImageCentered(assets.rockets[stage.kind], x, y, 0.75);
}

function drawProjectiles() {
  for (const fruit of state.projectiles) {
    ctx.fillStyle = "#ff8c1a";
    ctx.strokeStyle = "#bc5f00";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(fruit.x, fruit.y, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }
}

function drawExplosions() {
  for (const e of state.explosions) {
    const size = 28 - e.life;
    ctx.fillStyle = "rgba(255, 180, 71, 0.8)";
    ctx.beginPath();
    ctx.arc(e.x, e.y, size, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawSpeechBubble(x, y, width, text) {
  ctx.fillStyle = "#fff";
  ctx.strokeStyle = "#1d1d1d";
  ctx.lineWidth = 2;
  ctx.fillRect(x, y, width, 72);
  ctx.strokeRect(x, y, width, 72);
  ctx.beginPath();
  ctx.moveTo(x + 14, y + 72);
  ctx.lineTo(x + 34, y + 72);
  ctx.lineTo(x + 22, y + 90);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = "#111";
  ctx.font = "bold 20px Arial";
  wrapText(text, x + 12, y + 28, width - 24, 22);
}

function wrapText(text, x, y, maxWidth, lineHeight) {
  const words = text.split(" ");
  let line = "";
  for (const word of words) {
    const testLine = `${line}${word} `;
    if (ctx.measureText(testLine).width > maxWidth && line) {
      ctx.fillText(line, x, y);
      line = `${word} `;
      y += lineHeight;
    } else {
      line = testLine;
    }
  }
  ctx.fillText(line, x, y);
}

function drawDialogue() {
  if (currentStage().kind !== "sahar" || state.dialogueTimer <= 0) return;
  if (state.dialogueTimer > 160) {
    drawSpeechBubble(195, 250, 300, "Oh no! the fucking snakes are here!");
  } else if (state.dialogueTimer > 80) {
    drawSpeechBubble(520, 165, 370, "IT'S TIME, ITS TIME TO PRACTICE DISCIPLINE!");
  } else {
    drawSpeechBubble(520, 165, 350, "IT'S TIME TO DESTROY COGNITIVE DISSONANCE!");
  }
}

function drawHud() {
  ctx.fillStyle = "rgba(14,29,47,0.9)";
  ctx.fillRect(20, 20, 430, 130);
  ctx.fillStyle = "#fff";
  ctx.font = "bold 30px Arial";
  ctx.fillText("Clementine Defender", 40, 55);
  ctx.fillStyle = "#ffd45a";
  ctx.font = "bold 22px Arial";
  ctx.fillText(`${currentStage().name}: ${currentStage().kind.toUpperCase()}`, 40, 90);
  ctx.fillStyle = "#d4f0ff";
  ctx.font = "20px Arial";
  ctx.fillText(`Clementines left: ${state.ammo}`, 40, 122);

  const hpLeft = Math.max(0, currentStage().hp - state.stageHits);
  ctx.fillStyle = "#1d2430";
  ctx.fillRect(470, 28, 270, 30);
  ctx.fillStyle = hpLeft / currentStage().hp > 0.6 ? "#60d66a" : hpLeft / currentStage().hp > 0.3 ? "#ffbf47" : "#ff5d5d";
  ctx.fillRect(470, 28, 270 * (hpLeft / currentStage().hp), 30);
  ctx.fillStyle = "#fff";
  ctx.font = "bold 18px Arial";
  ctx.fillText(`Rocket Health ${hpLeft}/${currentStage().hp}`, 505, 49);

  ctx.fillStyle = "#1d2430";
  ctx.fillRect(760, 28, 180, 30);
  ctx.fillStyle = "#ff8c1a";
  ctx.fillRect(760, 28, 180 * ((state.power - 0.45) / (1.5 - 0.45)), 30);
  ctx.fillStyle = "#fff";
  ctx.fillText(`Power ${Math.round(state.power * 100)}%`, 792, 49);
}

function drawOverlay(title) {
  ctx.fillStyle = "rgba(16,24,32,0.9)";
  ctx.fillRect(215, 190, 570, 230);
  ctx.strokeStyle = "#ffd45a";
  ctx.lineWidth = 4;
  ctx.strokeRect(215, 190, 570, 230);
  ctx.fillStyle = "#ffd45a";
  ctx.font = "bold 42px Arial";
  ctx.fillText(title, 330, 250);
  ctx.fillStyle = "#fff";
  ctx.font = "bold 28px Arial";
  ctx.fillText(`Total hits landed: ${state.totalHits}`, 335, 310);
  ctx.font = "24px Arial";
  ctx.fillText("Tap Start / Throw to play again", 300, 360);
}

function render() {
  ctx.clearRect(0, 0, WIDTH, HEIGHT);
  const shakeX = state.screenShake > 0 ? (Math.random() * 2 - 1) * state.screenShake : 0;
  const shakeY = state.screenShake > 0 ? (Math.random() * 2 - 1) * (state.screenShake / 2) : 0;
  ctx.save();
  ctx.translate(shakeX, shakeY);
  drawBackground();
  drawPlayer();
  drawRocketStage();
  drawProjectiles();
  drawExplosions();
  drawDialogue();
  ctx.restore();
  drawHud();
  if (state.mode === "title") drawOverlay("Tap Start");
  if (state.mode === "won") drawOverlay("Victory");
  if (state.mode === "lost") drawOverlay("Mission Failed");
  statusText.textContent = state.message;
}

function loop() {
  update();
  render();
  requestAnimationFrame(loop);
}

aimSlider.addEventListener("input", () => {
  state.aim = Number(aimSlider.value);
});

powerSlider.addEventListener("input", () => {
  state.power = Number(powerSlider.value) / 100;
});

throwBtn.addEventListener("click", () => {
  if (state.mode === "won" || state.mode === "lost") {
    resetGame();
    return;
  }
  throwClementine();
});

canvas.addEventListener("pointerdown", (event) => {
  const rect = canvas.getBoundingClientRect();
  const x = (event.clientX - rect.left) / rect.width;
  if (x > 0.75) throwClementine();
});

loadAssets().then(() => {
  resetGame();
  loop();
});
